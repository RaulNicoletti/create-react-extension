console.log('Hello from the content scripts!');
